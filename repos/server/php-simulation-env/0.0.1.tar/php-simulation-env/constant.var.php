<?php

// fis.baidu.com

if (!defined('WWW_ROOT')) define ('WWW_ROOT', __DIR__ . '/../');
if (!defined('ROOT')) define ('ROOT', __DIR__ . '/');
