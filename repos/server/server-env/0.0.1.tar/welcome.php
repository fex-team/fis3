<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Welcome FIS-PLUS</title>
    </head>
    <body>
        <p>
            <?php
            ?>
        </p>
    </body>
</html>
