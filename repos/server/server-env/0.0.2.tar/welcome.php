<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Welcome FIS-PLUS</title>
        <style type="text/css">
        body {
            font-family: Consolas, 'Courier New', '宋体', 'monospace';
            line-height: 1.5em;
        }
        </style>
    </head>
    <body>
        <h1>Welcome，我是FIS-PLUS，史上最强大的前端集成解决方案</h1>
        <p>
        你要了解我，可能需要经过几个过程
        <ul>
            <li>移步到官网看一下快速入门 <a href="http://oak.baidu.com/fis-plus">http://oak.baidu.com/fis-plus</a></li>
            <li>还需要看看fis的配置API <a href="https://github.com/fex-team/fis/wiki">https://github.com/fex-team/fis/wiki</a></li>
            <li>开始畅游，书写漂亮的代码</li>
        </ul>
        </p>
    </body>
</html>
