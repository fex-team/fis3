<?php
class FISData {
    private $root;

    public function __construct($root) {
        $this->root = realpath(dirname(__FILE__) . '/../');
        if ($root) {
            $this->root = realpath($root);
        }
    }

    public function getData($tpl, $root) {
        if ($root) {
            $this->root = realpath($root);
        }

        $subpath = str_replace($this->root, '', $tpl);

        $data = array();
        if ($data = $this->getPHPData($subpath)) {
            //php data
        } else if ($data = $this->getJSONData($subpath)) {
            //json data
        }
        return $data;
    }

    private function getPHPData($subpath) {
        $file = $this->root . '/test/' . preg_replace('/\.[a-z]{2,6}$/i', '.php', $subpath);
        $ret = array();
        if (is_file($file)) {
            require_once($file);
            $ret = $fis_data;
            unset($fis_data);
        }
        return $ret;
    }

    private function getJSONData($subpath) {
        $file = $this->root . '/test/' . preg_replace('/\.[a-z]{2,6}/i', '.json', $subpath);
        $ret = array();
        if (is_file($file)) {
            $ret = json_decode(file_get_contents($file), true);
            if ($ret === null) {
                $ret = array();
            }
        }
        return $ret;
    }
}

/**
 * example:
 *  getData('/page/a.tpl')
 * result:
 *  /home/staff/.fis-tmp/www/test/page/a.php
 *  or
 *  /home/staff/.fis-tmp/www/test/page/a.json
 *
 * @param string $tpl template path
 * @return array
 */
function getData($tpl) {
    $dataIns = new FISData();
    return $dataIns->getData($tpl);
}

?>
