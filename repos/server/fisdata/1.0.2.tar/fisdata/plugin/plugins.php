<?php
require_once(PLUGIN_ROOT . "FISADOCData.class.php");
require_once(PLUGIN_ROOT . "FISJSONData.class.php");
require_once(PLUGIN_ROOT . "FISPHPData.class.php");

