<?php
class indexAction extends Bingo_Action_Abstract
{
	public function execute()
	{
		echo 'test::index';
	}
}