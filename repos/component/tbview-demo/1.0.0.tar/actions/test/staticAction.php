<?php
class staticAction extends Bingo_Action_Abstract
{
	public function execute()
	{
		echo 'test/static';		
	}
}