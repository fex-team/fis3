hello menu -----sdfadsafsa
<!-- sfd -->
<?php
BigPipe::import('frs:index.css');
$__component__->load('list', null, null, 'fff');?>

<?php BigPipe::scriptStart();?>

alert(456);

<?php BigPipe::scriptEnd();?>