hello list
<?
$e=new Exception();echo $e->getTraceAsString()."\n";