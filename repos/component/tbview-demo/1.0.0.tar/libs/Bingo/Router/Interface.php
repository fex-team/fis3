<?php
/**
 * Router�ӿ���
 * @author xuliqiang <xuliqiang@baidu.com>
 * @since 2010-02-24
 * @package bingo2.0
 *
 */
interface Bingo_Router_Interface
{
	public function getDispatchRouter($strRouter);
}