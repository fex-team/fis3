<?php
/**
 * 
 */
class Bingo_Exception extends Exception
{
    
}