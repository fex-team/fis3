<?php
require_once 'Bingo/Balance/Abstract.php';
class Bingo_Balance_Consistent extends Bingo_Balance_Abstract
{
	public function getConnection()
	{
		//TODO
	}
}