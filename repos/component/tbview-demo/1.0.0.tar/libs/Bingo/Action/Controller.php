<?php
class Bingo_Action_Controller
{
	public function init()
	{
		return true;
	}
}