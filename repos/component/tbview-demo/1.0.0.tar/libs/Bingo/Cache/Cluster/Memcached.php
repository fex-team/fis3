<?php 

require_once 'Third/Memcached/McClient.php';