<?php 

require_once 'Third/Zcache/zcache_adapter.class.php';