<?php
/**
 * У��������
 * @package Validator
 * @author xuliqiang@baidu.com
 * @since 2009-08-26
 *
 */
abstract class Bingo_Validate_Abstract
{
    abstract public function isValid($value);   
}