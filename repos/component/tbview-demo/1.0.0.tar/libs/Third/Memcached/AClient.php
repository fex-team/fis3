<?php
/***************************************************************************
 * 
 * Copyright (c) 2011 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file AClient.php
 * @author wangweibing(com@baidu.com)
 * @date 2011/05/18 11:04:37
 * @brief 
 * version: 1.0.8.2 
 **/

require_once(dirname(__FILE__) . "/aclient/aclient.php");

class Ak_AClient extends AClient {
}




/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
?>
