/**
 * @fileOverview pagelet 同步页面异步化的基础库
 * @author yansunrong
 * @version 1.0
 */

var baidu = require("tangram:base");
require("fis:history");
var pagelet = (function() {
    var _pagelets = []; //保存每次请求的访问url, 和pagelet。格式如[{url:'',pagelet:''},...]
    var _needCatchHistory = false; //是否需要处理hash变化的事件。false表示不需要
    var _sessionId = 0; //一个全局的ID，记录每次异步请求的ID.自增加
    var _urlPrefix = [location['protocol'], '//', location['host']].join(''); //如 http://www.baidu.com
    var _urlPrefixLength = _urlPrefix.length; //上的长度
    var _entryUri = _getURIFromHref(location['href']); //相对路径，如/photo/pagelet.tpl
    /**
     * 构建pagelet的内容。
     *
     * @function
     * @public
     * @param {Object} data,数据的内容。
     * @param {String} data.id pagelet的ID
     * @param {String} data.html pagelet的html内容
     * @param {Array} data.onload pagelet的脚本内容。字符串格式
     */

    function onArrive(data) {
        // pagelets[data.id] = data;
        var container = baidu.g(data.id);
        if (container) { //如何找到id就不继续了。
            container.innerHTML = data.html;
            if (data['onload'] && data['onload'].length) {
                for (var i = 0; i < data['onload'].length; i++) {
                    _globalEval(data['onload'][i]);
                }
            }
        }
    }

    /**
     * 发起script 请求得到pagelet。
     * @param  {string} url  请求的地址
     * @param  {string} pagelet 参数
     * @config {Object} args 参数
     * @config {Boolean} needPushState 是否需要更新history
     * @return {void}
     */

    function goURL(url, pagelet, args) {
        url = _getURIFromHref(url);
        pagelet = pagelet || 'all'; //如果没有指定，则表示全部
        args = args || {};
        var queryJson = {
            ajax: 1,
            session: ++_sessionId,
            pagelet: pagelet
        };
        var argsURL = baidu.url.jsonToQuery(queryJson);
        var requestUrl = url + '?' + argsURL + '&t=' + new Date().getTime();

        var pageletScript = document.createElement('script');
        pageletScript.setAttribute('type', 'text/javascript');
        pageletScript.setAttribute('src', requestUrl);
        pageletScript.setAttribute('defer', 'defer');
        pageletScript.setAttribute('id', '_fis_pagelet_script_' + _sessionId);
        document.getElementsByTagName("head")[0].appendChild(pageletScript); 

        //添加到发送列表中。
        _pagelets[_sessionId] = {
            url: url,
            pagelet: pagelet
        };

        //设置hash,区别IE和其它浏览。
        if (baidu.browser.ie) {
            if (args['needPushState'] != false) {
                _needCatchHistory = false;
                //如果是当前页刷新就不需要动#
                if (location.hash == '' && _entryUri == url) {
                    return;
                }
                if (location.hash.substring(2) != url) {
                    location.hash = '!' + url;
                }
            }
        } else if (args['needPushState'] != false) {
            //如果是当前页，就需要处理history相关的事情了。
            if (url == _entryUri) {
                return;
            }
            _entryUri = url;
            history.pushState({
                url: url,
                pagelet: pagelet
            }, 'pagelet', url);
        }
    }

    //处理绑定在document的点击事件，用于截获a标签的正常请求。

    function _documentClickHandler(e) {
        var element, target, href, pagelet;
        e = baidu.event.get(e);
        element = baidu.event.getTarget(e);
        element = baidu.dom.getAncestorByTag(element, 'A') || element;
        if (!element) return;
        target = baidu.dom.getAttr(element, 'target');
        if (target && target != "_self") return;
        href = baidu.dom.getAttr(element, 'href');
        if (!href) return;
        pagelet = baidu.dom.getAttr(element, 'pagelet');
        if (pagelet == null || pagelet == '') return;
        //判断是否为非本域的请求。
        if(_checkHref(href)){
            goURL(href, pagelet);
            baidu.event.preventDefault(e);
        }
    }

    //绑定事件。
    baidu.on(document,'click',_documentClickHandler);


    /**
     * 检查href是不是合理的，主要检查是否本域的
     * @param  {string} href  需要检查的地址
     * @return {boolean} true表示合理，false不合适
     */
    function _checkHref(href){
        if(href.match(/^https?:\/\//)){
            return href.indexOf(_urlPrefix) == 0;
        }
        return true;
    }
    //执行JS，传入js语句
    function _globalEval(src) {
        if (window.execScript) {
            window.execScript(src);
            return;
        }
        var fn = function() {
                window.eval.call(window, src);
            };
        fn();
    };

    // 获取相对地址
    function _getURIFromHref(href) {
        if (href.indexOf('#!') > 0) {
            return href.substring(0, href.indexOf('#'));
        }
        var uri;
        if (href.indexOf('/') == 0) {
            uri =  href;
        }else if (href.indexOf(_urlPrefix + '/') == 0) { //完整地址,如http://www.baidu.com...
            uri = href.substring(_urlPrefixLength) || '/';
        }else{
            alert('不能使用相对路径');
        } 
        //如果有#,且不是#!,则为了正常使用，需要清除#
        uri = uri.indexOf('#') > 0 ? uri.substring(0, uri.indexOf('#')) : uri;
        return uri;
    }



    //IE下的hash变化时候的操作
    function _handleHashChange() {
        if (!_needCatchHistory) {
            _needCatchHistory = true;
        } else if (location.hash) {
            goURL(location.hash.substring(2), null, {
                needPushState: false
            });
        }
    }


    /**
     * 得到返回结果之前,页面开始执行第一个onArrive之前，派发事件。
     * @param {String} index,sessionID的id。
     */

    //function sessionStart(index) {
      //  baidu.lang.eventCenter.dispatchEvent('pagelet_start', _pagelets[index]);
    //}

    /**
     * 一次请求，pagelet执行完成之派发事件。
     * @param {String} index,sessionID的id。
     */

    function sessionEnd(index) {
        var script = baidu.g('_fis_pagelet_script_' + index);
        if (script) baidu.dom.remove(script);
        baidu.lang.eventCenter.dispatchEvent('pagelet_end', _pagelets[index]);
    }

    //绑定history变化时的处理
    baidu.on(window, 'popstate', function(e) {
        if (e.state) {
            var state = e.state;
            goURL(state.url, state.pagelet, {
                needPushState: false
            });
        }
    });
    //添加hash变化的历史
    if (baidu.browser.ie) {
        if (baidu.browser.ie < 8) {
            baidu.dom.ready(function() {
                baidu.history.listen(function() {
                    _handleHashChange();
                });
            });
        } else {
            window.onhashchange = _handleHashChange;
        }
    }
    return {
        onArrive: onArrive,
        goURL: goURL,
        sessionEnd: sessionEnd
    }
})();

window.pagelet = pagelet