/**
 *
 * @file: promise.js
 * @author: tconzi@gmail.com
 * @desc: 提供异步操作简化方案，参考：http://wiki.commonjs.org/wiki/Promises/A
 *
 * */

var Promise = function() {
    this.result = [];
    this.failResult = [];
    this.status = 0;
    this.resolveQuery = [];
    this.beforeQuery = [];
    this.afterQuery = [];
    this.rejectQuery = [];
    this.resultCache = [];
    this.resultCount = 0;
    this.returnCount = 0;
}

Promise.prototype = {

    //空函数
    empty : function() {
    },
    //when中有一个就返回
    any : function() {
        this.returnCount = 1;
    },
    //when中有i个返回就执行完成函数
    some : function(i) {
        this.returnCount = Math.min(i, this.resultCount);
    },
    //when中所有的结果都返回之后才能执行
    all : function() {
        this.returnCount = this.resultCount;
    },
    /**
     *  可传入函数或promise对象，如果是promise对象，则等待该对象完成。如果是函数，则直接返回函数的执行结果
     *
     * */
    when : function() {
        var arg = arguments;
        this.resultCount = this.returnCount = arguments.length;
        var done = 0;
        var me = this;
        function resolve(i) {
            return function(result) {

                me.resultCache[i] = result;

                if(++done == me.returnCount) {
                    me.resolve();
                }
            }
        }

        for(var i = 0, l = arg.length; i < l; i++) {
            var p = arg[i];
            if( typeof p === "function") {
                resolve(i)(p());
            }
            if( p instanceof Promise) {
                p.then(resolve(i), this.reject);
            }

            /*
             //可以支持 string和[eventtype ,params]的方式来调用，暂时就算了
             if(typeof p =="string"  || typeof p =="array"){
             if(typeof p == 'string'){
             p = [p];
             }

             EC.when(p).then(resolve(i));

             }
             */
        }

        return this;
    },
    then : function(done, fail) {
        done = done || this.empty;
        fail = fail || this.empty;

        this.resolveQuery.push(done);
        this.rejectQuery.push(fail);

        if(this.status == 1) {
            this.resolve();
        }

        if(this.status == 2) {
            this.reject();
        }

        return this;
    },
    before : function(done) {
        this.beforeQuery.push(done);

        return this;
    },
    after : function(done) {
        this.afterQuery.push(done);
        return this;
    },
    resolve : function() {

        //console.log("resolved"+ Array.prototype.slice.call(arguments,0));
        if(arguments.length > 0) {

            this.resultCache = this.result = Array.prototype.slice.call(arguments, 0);
        } else {
            this.result = this.resultCache;
        }
        this.status = 1;

        var me = this;
        function done(query) {
            for(var i = 0, l = query.length; i < l; i++) {
                query[i].apply(me, me.result);
            }
            query.length = 0;
        }

        done(this.beforeQuery);
        done(this.resolveQuery);
        done(this.afterQuery);
        return this;
    },
    reject : function() {
        if(arguments.length > 0) {
            this.failResult = Array.prototype.slice.call(arguments, 0);
        }
        this.status = 0;
        for(var i = 0, l = this.rejectQuery.length; i < l; i++) {
            this.rejectQuery[i].apply(this, this.failResult);
        }

        return this;
    },
    isPromise : true,
    done : function() {
        this.resolve.apply(this, arguments);
    },
    fail : function() {
        this.reject.apply(this, arguments);
    }
};
//end prototype

var ec = require("fis:event");

/**
 *事件中心，支持when().then 
 * @method  eventCenter.fire 实现类似dispatchEvent的功能，不过增加.when的支持方便做事件流处理;
 * @method  eventCenter.when ( event || [event , options]),支持对多个事件做判断,这里为了减少依赖，不做过多的嵌套 
 */
ec.when = function() {

    //debugger;
    var p = new promise.promise();
    var list = [];
    baidu.each(arguments, function(item, index) {( typeof item == "string") && ( item = [item]);
        var promise = ec.fire.apply(ec, item);
        list.push(promise);
    });
    return p.when.apply(p, list);

}

ec.fire = function() {
    //debugger;
    var arg = Array.prototype.slice.call(arguments, 1);
    var e = arguments[0];
    if(baidu.lang.isString(e)) {
        e = new baidu.lang.Event(e);
    }

    e.promise = new promise.promise();

    arg.unshift(e);
    ec.dispatchEvent.apply(ec, arg);
    return e.promise;
}

exports.promise = Promise;
