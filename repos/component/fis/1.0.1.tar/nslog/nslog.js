/*jslint camel:false*/
/*
* @fileoverview nslog统计相关的功能
*
* @author tconzi@gmail.com
*
* @version 1.0
*/

/**
 * 供nslog调用的内部方法
 * @type function
 * @param {String} url 被点击链接的url ，如果是展现的统计，则为当前页的url
 * @param {number} type 为统计类型 ,type 详细内容，由各组自己根据《公共资源使用规范》中的nslog规范制定
 * @param {Object} [other] 扩展参数，object类型
 */
function _nslog_send(url, type, other) {//nslog统计
    var t = (new Date()).getTime();
    var params = ["http://nsclick.baidu.com/v.gif?pid=" + nslog.pid, "url=" + encodeURIComponent(url), "type=" + type, "t=" + t];
    for(var k in other) {
        params.push(k + "=" + other[k]);
    }
    for(var k in nslog.log_params) {
        params.push(k + "=" + nslog.log_params[k]);
    }
    //发送请求
    nslog.req(params.join("&"));
}

var ie6 = false;
if(/msie (\d+\.\d)/i.test(navigator.userAgent)) {
    var ie = document.documentMode || +RegExp['\x241'];
    ie6 = ie == 6;
}

// 解决IE6下连续发送统计请求丢失的问题 begin
var waitinglist = []
var sending4ie6 = false;
/**@ignore*/
var send4ie6 = function() {
    if(waitinglist.length == 0) {
        sending4ie6 = false;
    } else {
        var params = waitinglist.shift();
        _nslog_send(params[0], params[1], params[2]);

        setTimeout(send4ie6, 100);
    }
};
// 解决IE6下连续发送统计请求丢失的问题 end

/**
 * @constructor
 * @param {String} url 被点击链接的url ，如果是展现的统计，则为当前页的url
 * @param {number} type 为统计类型 ,type 详细内容由产品线自己确定，参考nslog统计规范
 * @param {Object} [other] 扩展参数，object类型
 * @example pid、url、type三个数是必须的，并且位置固定。pid代表具体产品线，如果是新产品使用，请参考log.baidu.com上的指南来申请。type为统计类型
 */
nslog = function(url, type, other) {//nslog统计
    if(ie6) {
        waitinglist.push([url, type, other]);

        if(!sending4ie6) {
            sending4ie6 = true;
            send4ie6();
        }
    } else {
        _nslog_send(url, type, other);
    }
};

nslog.log_params = {};
/**
 * 设置nslog的参数,全局都将带上这些参数
 * @param {String} key 参数的key
 * @param {String} value 参数的value
 */
nslog.set = function(key, value) {
    nslog.log_params[key] = value;
};
//session id ,用于标识同一用户在同一页面的访问情况
nslog.sid = ((new Date()).getTime() + "_" + Math.round(Math.random() * 2147483637));

/**@ignore*/
nslog.req = function(url) {
    //图片请求函数，用于统计
    var n = "fis_nslog_" + (new Date()).getTime();
    var c = window[n] = new Image();
    //将image对象赋给全局变量，防止被当做垃圾回收，造成请求失败。
    c.onload = c.onerror = function() {
        window[n] = null;
        //垃圾回收
    };
    c.src = url;
    c = null;
    //垃圾回收
};
//产品线的id,需要配置
nslog.pid = "$PID$";
//todo ，需要编译解决

exports.nslog = nslog;

exports.setPid = function(pid) {
    nslog.pid = pid;
}
//偶尔用于其他的统计
exports.get = nslog.req;
