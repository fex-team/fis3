F.use(["tangram:base","fis:nslog"],function(baidu,log){

    var nslog = log.nslog;

    //默认绑定事件，简单的nslog统计就可以使用data-nslog ="type" 或data-nslog-area="type"来实现。
    //对于复杂的事件，可以参考这里的实现来自己扩展
    baidu.dom.ready(function() {
        baidu.on(document, "mousedown", function(e) {
            var evt = baidu.event.get(e);
            var ele = evt.target;
            //对于nslog向上寻找三层,最多支持 <a><span><img /></span>，nslog-area冒泡到顶层，两个同时找，nslog找到一个就停止,nslog-area把所有找到的都抛出。
            var deep = 3;

            var linkClick = false; //a标签是否被点击
            var targetTagName = "" ; //起作用的tag
            var linkHref = ''; //a标签的地址
            var continueNslog = true; //是否继续发送nslog
            var url = window.location.href;

            while (ele) {
                if (ele.nodeType == 1) {
                    //对于包含data-nslog = "type" 的元素，第一个被找到的元素会发送nslog
                    var tp = ele.getAttribute("data-nslog");
                    var area = ele.getAttribute("data-nslog-area");


                    var extra = {
                        x: evt.pageX,
                        y: evt.pageY,
                        tag: ele.tagName.toLowerCase()
                    };

                    var logDetail = ele.getAttribute('data-log-data-detail');
                    if (logDetail) {
                        extra['log-data-detail'] = logDetail;
                    }


                    if (deep > 0) {
                        url = ele.href || window.location.href;
                        if (continueNslog && tp) {
                            //可为统计增加附加项  标签内增加log-data-detail属性
                            var onceFlag = ele.getAttribute('data-log-once-flag');
                            if (!onceFlag || !ele.logFlag) {
                                nslog(url, tp, extra);

                                continueNslog = false;
                                if (onceFlag) {
                                    ele.logFlag = true;
                                }
                            }
                        }


                        //判断是否需要发送nslog-area的统计信息
                        if ((!linkClick && ele.href)||
                                (ele.tagName.toLowerCase() == "input" &&( ele.type == "button"|| ele.type=="submit" ))||
                                (ele.tagName.toLowerCase() == "button")){
                            linkClick = true;
                            linkHref = url;
                        }
                    } //end deep>0

                    //data-nslog-type只对a标签或button管用
                    if (linkClick && area) {
                        nslog(linkHref, area , extra);
                    }
                } // end nodeType == 1

                deep--;
                ele = ele.parentNode;
            }
            ele = null;
        });
    });
});
