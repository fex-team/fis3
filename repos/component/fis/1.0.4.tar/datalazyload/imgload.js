var IMG_SRC_DATA = 'data-fis-lazyload',
    baidu = require('tangram:base'),
    base = require('./base.js');

// 加载图片 src，将图片内data-fis-lazyload属性内保存的图片地址图设为图片的src，进行加载
var loadImgSrc = function (img, flag) {
    flag = flag || IMG_SRC_DATA;
    var dataSrc = img.getAttribute(flag);

    if(dataSrc && img.src != dataSrc) {
        img.src = dataSrc;
        img.removeAttribute(flag);
    }
};




var imgload = function(containers) {
    var self = this;
    self._images = [];
    self.containers = baidu(containers);
};

imgload.prototype = {

    _filterImg: function(img) {
        var self = this,
            dataSrc = img.getAttribute(IMG_SRC_DATA),
            placeholder = self.placeholder;

        if (dataSrc) {
            if (placeholder) {
                img.src = placeholder;
            }
            return true;
        }
    },

    _filterItems: function() {
        var self = this,
            n, N, imgs, img,
            containers = self.containers,
            lazyImgs = [];

        for(n = 0, N = containers.length; n < N; ++n) {
            imgs = base.removeExisting(baidu(containers[n]).find('img'), lazyImgs);
            lazyImgs = lazyImgs.concat(baidu.array(imgs).filter(self._filterImg, self));
        }

        self._images = lazyImgs;
    },


    /**
     * lazyload img
     * @private
     */
    _loadImgs: function () {
        var self = this;
        self._images = baidu.array(self._images).filter(self._loadImg, self);
    },

    /**
     * check img whether it is inside viewport and load
     * @private
     */
    _loadImg: function (img) {
        var self = this;
        if (!base.inDocument(img)) {

        } else if (base._checkElemInViewport(img, self.containers)) {
            loadImgSrc(img);
        } else {
            return true;
        }
    }

};

exports = imgload;