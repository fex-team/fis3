var AREA_DATA_CLASS = 'fis-datalazyload',
    baidu = require('tangram:base'),
    NONE = 'none',
    base = require('./base.js');

function loadAreaData(area, execScript) {
    // 采用隐藏 textarea 但不去除方式，去除会引发 Chrome 下错乱
    area.style.display = NONE;
    area.className = '';
    var content =document.createElement("div");
    area.parentNode.insertBefore(content, area);
    // execScript 是否执行script
    baidu(content).html(area.value);
}

function filterArea(area) {
    return baidu(area).hasClass(AREA_DATA_CLASS);
}

var areaload = function(containers) {

    var self = this;

    self._areaes = [];
    self.containers = baidu(containers);
};

areaload.prototype = {

    _filterItems: function() {
        var self = this,
            n, N, _areaes,
            containers = self.containers,
            lazyAreaes = [];

        for(n = 0, N = containers.length; n < N; ++n) {
            _areaes = base.removeExisting(baidu(containers[n]).find('textarea'), lazyAreaes);
            lazyAreaes = lazyAreaes.concat(baidu.array(_areaes).filter(filterArea, self));
        }

        self._areaes = lazyAreaes;
    },

    /**
     * lazyload textareas
     * @private
     */
    _loadAreas: function () {
        var self = this;
        self._areaes = baidu.array(self._areaes).filter(self._loadArea, self);
    },

    /**
     * check textarea whether it is inside viewport and load
     * @private
     */
    _loadArea: function (area) {
        var self = this;
        if (!base.inDocument(area)) {

        } else if (base._checkElemInViewport(area, self.containers)) {
            loadAreaData(area, this.execScript);
        } else {
            return true;
        }
    }


};

exports = areaload;