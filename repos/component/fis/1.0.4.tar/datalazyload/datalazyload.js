var baidu = require('tangram:base'),
    areaload = require('./areaload.js'),
    imgload = require('./imgload.js'),
    base = require('./base.js'),

    win = baidu(this).getWindow(),
    doc = baidu(this).getDocument(),
    DEFAULT = 'defalut',
    NONE = 'none',
    SCROLL = 'scroll',
    TOUCH_MOVE = 'touchmove',
    RESIZE = 'resize',
    DURATION = 100;

var DataLazyLoad =  function(containers, config) {
    var self = this;

    if(!(self instanceof DataLazyLoad)) {
        return new DataLazyLoad(containers, config);
    }

    //不设置containers时，container为doc
    if(!containers){
        containers = doc;
    }
    self.containers = baidu(containers);

    //预加载的区域大小，不设置时，预加载一屏
    base.diff = self.diff = DEFAULT;

    self.autoDestroy = true;

    //图片没加载时的占位符
    self.placeholder = {};

    //是否执行 textarea 里面的脚本
    self.execScript = true;

    config = config || {};
    baidu.object.extend(self, config);

    self._callbacks = {els: [], fns: []};

    self.imgload = new imgload(self.containers);
    self.areaload = new areaload(self.containers);

    self._init();
};


DataLazyLoad.prototype = {

    _init: function() {
        var self = this;
        self._filterItems();
        self._initLoadEvent();
    },

    //获取需要延迟加载的图片和textarea
    _filterItems: function() {
        var self = this;
        self.imgload._filterItems();
        self.areaload._filterItems();
    },

    _initLoadEvent: function () {
        var self = this,
            autoDestroy = self.autoDestroy,
        // 加载延迟项
            loadItems = function () {
                self._loadItems();
                if(autoDestroy && self._getItemsLength() == 0) {
                    self.destroy();
                }
            };
        // 加载函数，避免scroll，resize等连续事件中，在DURATION内被执行多次
        load = function () {
            setTimeout(loadItems, DURATION);
        };

        baidu(win).on(SCROLL, load);
        baidu(win).on(TOUCH_MOVE, load);
        baidu(win).on(RESIZE, load);

        baidu(self.containers).each(function(index, item) {
            if(base.isValidContainer(item)) {
                baidu(item).on(SCROLL, load);
                baidu(item).on(TOUCH_MOVE, load);
            }
        });

        self._loadFn = load;

        // 需要立即加载一次，以保证第一屏的延迟项可见
        if (self._getItemsLength()) {
            baidu(doc).ready(loadItems);
        }
    },

    refresh: function() {
        this._loadItems();
    },

    _loadItems: function() {
        var self = this;
        self.imgload._loadImgs();
        self.areaload._loadAreas();
        self._fireCallbacks();
    },

    _fireCallbacks: function() {
        var self = this,
            callbacks = self._callbacks,
            containers =self.containers,
            els = callbacks.els,
            fns = callbacks.fns,
            remove = 0,
            i, el, fn, remainEls = [],
            remainFns = [];

        for (i = 0; (el = els[i]) && (fn = fns[i++]);) {
            remove = false;
            if (!base.inDocument(el)) {
                remove = true;
            } else if (base._checkElemInViewport(el, containers)) {
                remove = fn.call(el);
            }
            if (remove === false) {
                remainEls.push(el);
                remainFns.push(fn);
            }
        }
        callbacks.els = remainEls;
        callbacks.fns = remainFns;
    },

    addCallback: function(el ,fn) {
        var self = this,
            callbacks = self._callbacks;
        el = baidu(el);

        // el 为tangram dom对象，是数组，添加的时候循环添加成单个的
        if(el.length !== 0 && baidu.type(fn) == 'function') {
            baidu(el).each(function(index, curEl) {
                callbacks.els.push(curEl);
                callbacks.fns.push(fn);
            });
        }

        self._fireCallbacks();
    },

    /**
     * Remove a callback function.
     * @param {HTMLElement|String} el html element to be monitored.
     * @param {Function} [fn] Callback function to be called when el is in viewport.
     *                        If not specified, remove all callbacks associated with el.
     */
    removeCallback: function(el, fn) {
        var callbacks = this._callbacks,
            els = [],
            fns = [],
            curFns = callbacks.fns;

        el = baidu(el);

        baidu(callbacks.els).each(function(callback_index, callback_curEl) {
            //callbacks 和 el 都是 tangram dom对象，都是数组，需要循环比较
            var flag = 0;
            baidu(el).each(function(new_index, new_curEl) {
                if (callback_curEl == new_curEl) {
                    if (fn === undefined || fn == curFns[callback_index]) {
                        flag = 1;
                        return;
                    }
                }
            });
            if(flag == 0) {
                els.push(callback_curEl);
                fns.push(curFns[callback_index]);
            }
        });
        callbacks.fns = fns;
        callbacks.els = els;
    },



    /**
     * get num of items waiting to lazyload
     * 或许需要延迟加载项目的数目
     * @private
     */
    _getItemsLength: function () {
        var self = this;
        return self.imgload._images.length + self.areaload._areaes.length + self._callbacks.els.length;
    },


    /**
     * Destroy this component.Will fire destroy event.
     */
    destroy: function () {
        var self = this, load = self._loadFn;
        baidu(win).off(SCROLL, load);
        baidu(win).off(TOUCH_MOVE, load);
        baidu(win).off(RESIZE, load);

        //load.stop();

        baidu(self.containers).each(function (c) {
            if (base.isValidContainer(c)) {
                baidu(c).off(SCROLL, load);
                baidu(c).off(TOUCH_MOVE, load);
            }
        });
        self._callbacks.els = [];
        self._callbacks.fns = [];
     //   self.imgload = {};
     //   self.areaload = {};
        //     console.log("datalazyload is destroyed!");
        //    self.fire("destroy");
    }
};

exports = DataLazyLoad;