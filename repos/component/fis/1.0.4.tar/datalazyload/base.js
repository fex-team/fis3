var baidu = require('tangram:base'),
    win = baidu(this).getWindow(),
    doc = baidu(this).getDocument(),
    DEFAULT = 'defalut',
    NONE = 'none';


var base = {

    diff: DEFAULT,

    isValidContainer: function(c) {
        return c.nodeType != 9;
    },

    inDocument: function(el) {
        return baidu(doc).contains(el);
    },

    getContainer: function(el, cs) {
        var self = this;
        for(var i = 0; i < cs.length; i++) {
            if(self.isValidContainer(cs[i])) {
                if(baidu(cs[i]).contains(el)) {
                    return cs[i];
                }
            }
        }
        return 0;
    },

    removeExisting : function(newed, exists) {
        var ret = [];
        for(var i = 0; i< newed.length; i++) {
            if(!baidu.array(exists).contains(newed[i])) {
                ret.push(newed[i]);
            }
        }
        return ret;
    },

// 判断两块区域是否相交
    isCross : function(r1, r2) {
        var r = {};
        r.top = Math.max(parseFloat(r1.top), parseFloat(r2.top));
        r.bottom = Math.min(parseFloat(r1.bottom), parseFloat(r2.bottom));
        r.left = Math.max(parseFloat(r1.left), parseFloat(r2.left));
        r.right = Math.min(parseFloat(r1.right), parseFloat(r2.right));
        return r.bottom >= r.top && r.right >= r.left;
    },

     _getBoundingRect : function(c) {
        var vh, vw, left, top;

        if(c !== undefined  && baidu.type(c) !== 'Window' &&c.nodeType != 9) {
            vh = baidu(c).outerHeight();
            vw = baidu(c).outerWidth();
            var offset = baidu(c).offset();
            left = offset.left;
            top = offset.top;
        } else {
            vh = baidu(win).height();
            vw = baidu(win).width();
            left = baidu(win).scrollLeft();
            top = baidu(win).scrollTop();
        }

        var diff = this.diff,
            diffX = diff === DEFAULT ? vw : diff,
            diffX0 = 0,
            diffX1 = diffX,
            diffY = diff === DEFAULT ? vh : diff,
        // 兼容，默认只向下预读
            diffY0 = 0,
            diffY1 = diffY,
            right = left + vw,
            bottom = top + vh;

        if (baidu.type(diff) == 'Object') {
            diffX0 = diff.left || 0;
            diffX1 = diff.right || 0;
            diffY0 = diff.top || 0;
            diffY1 = diff.bottom || 0;
        }

        left -= diffX0;
        right += diffX1;
        top -= diffY0;
        bottom += diffY1;

        return {
            left: left,
            top: top,
            right: right,
            bottom: bottom
        };
     },


     _checkElemInViewport :  function(elem, containers) {
        // it's better to removeElements, but if user want to append it later
        if (!baidu(doc).contains(elem)) {
            return false;
        }
        // 注：不处理 elem display: none 或处于 display none 元素内的情景
        var self = this,
            elemOffset = baidu(elem).offset(),
            inContainer = true,
            container = self.getContainer(elem, containers),
            windowRegion = self._getBoundingRect(),
            inWin,
            containerRegion,
            left = elemOffset.left,
            top = elemOffset.top,
            elemRegion = {
                left: left,
                top: top,
                right: left + baidu(elem).outerWidth(),
                bottom: top + baidu(elem).outerHeight()
            };

        if (container) {
            containerRegion = self._getBoundingRect(container);
            inContainer = self.isCross(containerRegion, elemRegion);
        }

        // 确保在容器内出现
        // 并且在视窗内也出现
        inWin = self.isCross(windowRegion, elemRegion);
        return inContainer && inWin;
    }
};

exports = base;