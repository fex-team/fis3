/**
 * @fileOverview 事件中心模块，直接使用tangram.lang.eventCenter
 * @author tangram
 * @version 1.0
 */
var baidu = require("tangram:base");

baidu.lang.Class.prototype.once = function(eventType, handle, key) {
    var me = this;
    function onceHandle(e) {
        handle.apply(me, arguments);
        me.removeEventListener(eventType, onceHandle, key);
    }


    this.addEventListener(eventType, onceHandle, key);
}

/**
 * @method  eventCenter.on
 * @method  eventCenter.un
 * @method  eventCenter.once
 *
 * */

var ec = baidu.lang.eventCenter;
ec.once = ec.once;
ec.on = ec.addEventListener;
ec.un = ec.removeEventListener;
ec.fire = ec.dispatchEvent;

exports.eventCenter = ec;
