var baidu = require('common:static/common/lib/tangram/base/base.js');
/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 */

require('common:static/common/lib/tangram/parser/parser.js');
require('common:static/common/lib/tangram/parser/Parser/Parser.js');
require('common:static/common/lib/tangram/parser/_jpath/_jpath.js');
baidu.parser.Json = baidu.parser.Json || (function(){

    /**
     * JSON操作解析器
     * @public
     * @class
     */
    return function(options){
        
        var parser = new baidu.parser.Parser(options);
        parser._type = baidu.parser.type.JSON;

        baidu.extend(parser, {
       
            _jPath: null,

           /**
            * 转换数据
            * @private
            * @param {String|Object} JSON
            * @return {Boolean}
            */
            _parser: function(JSON){
                var me = this;

                if(baidu.lang.isString(JSON)){

                    try{
                        JSON = baidu.json.parse(JSON);
                    }catch(e){
                        return false;
                    }   
                }

                me._jPath = new JPath(JSON);
                me._dom = me._jPath.root();
                return true;
            },

            /**
             * 使用JPath获取数据并返回
             * @public
             * @param {String} Path
             * @return {Array}
             */
            _query: function(JPath){
                var me = this;
                return me._jPath ? me._jPath.query(JPath) : [];
            }

        });
        return parser;
    };
})();

module.exports  = baidu['parser']['Json'];
