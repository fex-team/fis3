var baidu = require('common:static/common/lib/tangram/base/base.js');
/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 */

require('common:static/common/lib/tangram/parser/parser.js');
baidu.parser.type = {
    'XML': 'Xml',
    'JSON': 'Json',
    'HTML': 'Html'
};

module.exports  = baidu['parser']['type'];
