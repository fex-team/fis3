var baidu = require('common:static/common/lib/tangram/base/base.js');
///import baidu;
/**
 * 各种页面的UI组件
 * @namespace baidu.ui
 */
baidu.ui = baidu.ui || { version: '1.3.9' };

module.exports  = baidu['ui'];
