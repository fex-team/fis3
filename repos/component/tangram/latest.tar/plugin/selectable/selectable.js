var baidu = require('common:static/common/lib/tangram/base/base.js');


baidu.dom.extend({
    isCrash : function(selector,strict){
        if(!arguments.length){ 
            return false; 
        };

        //传入的元素，get first
        var me = this,
            ele = baidu.dom(selector).eq(0),
            o = ele.offset(),
            w = ele.outerWidth(),
            h = ele.outerHeight(),
            num = me.size(),

            //检测算子，传入四个值比较，strict（是否严格）
            check = function(top,right,bottom,left,strict){
                if(strict){

                    //严格模式，一定要在容器内
                    if((o.top>=top)&&((o.top+h)<=bottom)&&(o.left>=left)&&((o.left+w)<=right)){
                        return true;
                    };

                }else{

                    //非严格模式，有碰撞或交集即可
                    if(((o.top+h)>=top)&&(o.top<=bottom)&&((o.left+w)>=left)&&(o.left<=right)){
                        return true;
                    };
                };
            };

        for(var i = 0; i < num; i++ ){
            var _ele = me.eq(i),
                _o = _ele.offset(),
                _w = _ele.eq(i).outerWidth(),
                _h = _ele.eq(i).outerHeight();

            if(check(_o.top,_o.left+_w,_o.top+_h,_o.left,strict)){
                return true;
            };
        };

        return false;
    }
});

// //检测两区域是否碰撞
// check(a1,a2){
//     if(a1.top>a2.bottom||a1.bottom<a2.top||a1.left>a2.right||a1.right<a2.left){
//         return false;
//     }else{
//         return true;
//     };
// };

baidu.plugin = baidu.plugin || {};
baidu.plugin._util_ = baidu.plugin._util_ || {};

baidu.plugin._util_.rubberSelect = function(options){
    var doc = baidu.dom(document),
        opts = options || {},

        //限制可触发的范围,selector或者是Object，来自options.range
        range,

        //监测点击是否在限制区内，在为true
        rangeFlag,

        //TODO：以后可以考虑支持enter和leave事件
        //关注的元素，来自options.focus
        //focus,

        //遮罩层虚线，具体样式在CSS中设置
        mask,

        //第一次mousedown时的鼠标位置
        x1,y1,
        x2,y2,
        _x2,_y2,

        //函数节流计时器
        timer,

        //延时0.15秒计时器
        delayTimer,

        handle = function(e){
            clearTimeout(delayTimer);
            x1 = e.pageX;
            y1 = e.pageY;

            //监测范围
            if(range){

                //不在限制范围内
                if(x1<range.left||x1>range.right||y1<range.top||y1>range.bottom){
                    rangeFlag = false;
                    return;
                };
            };

            rangeFlag = true;            
            doc.trigger('rubberselectstart');

            //为了兼容快速点击的情况
            doc.trigger('rubberselecting');

            //防止其他实例将mask清除了。
            setMask();
            mask.width(0).height(0).show().offset({left:x1,top:y1});

            doc.on('mousemove',ingHandle);
            
            //修正拖曳过程中页面里的文字会被选中
            doc.on('selectstart',unselect);

            //设置鼠标粘滞
            if (mask.setCapture) {
                mask.setCapture();
            } else if (window.captureEvents) {
                window.captureEvents(Event.MOUSEMOVE|Event.MOUSEUP);
            };

            //清除鼠标已选择元素
            if(document.selection){
                document.selection.empty && document.selection.empty();
            }else if(window.getSelection){
                window.getSelection().removeAllRanges();
            };      
        },

        ingHandle = function(e){

            //增加函数节流，防止事件频繁触发函数，影响性能
            clearTimeout(timer);
            timer = setTimeout(function(){
                doc.trigger('rubberselecting');
                _x2 = e.pageX;
                _y2 = e.pageY;

                //监测范围
                if(range){

                    //不在限制范围内
                    if(_x2<range.left){
                        x2 = range.left;
                    }else if(_x2>range.right){
                        x2 = range.right;
                    }else{
                        x2 = _x2;
                    };
                    if(_y2<range.top){
                        y2 = range.top;
                    }else if(_y2>range.bottom){
                        y2 = range.bottom;
                    }else{
                        y2 = _y2;
                    };
                }else{
                    x2 = _x2;
                    y2 = _y2;
                };

                //橡皮筋移动算子
                //TODO： 此处的width和height应该减去border的宽度
                if(x2>x1&&y2>y1){
                    mask.width(x2-x1).height(y2-y1);
                }else if(x2>x1&&y1>y2){
                    mask.width(x2-x1).height(y1-y2).offset({left:x1,top:y2});
                }else if(x1>x2&&y1<y2){
                    mask.width(x1-x2).height(y2-y1).offset({left:x2,top:y1});
                }else if(x1>x2&&y1>y2){
                    mask.width(x1-x2).height(y1-y2).offset({left:x2,top:y2});
                };

            //这里是因为我喜欢3这个数字，所以用3毫秒。    
            },3);
        },

        endHandle = function(){
            if(rangeFlag){

                doc.off('selectstart',unselect);    
                doc.off('mousemove',ingHandle);

                //解除鼠标粘滞
                if (mask.releaseCapture) {
                    mask.releaseCapture();
                } else if (window.releaseEvents) {
                    window.releaseEvents(Event.MOUSEMOVE|Event.MOUSEUP);
                };
                clearTimeout(delayTimer);
                delayTimer = setTimeout(function(){
                    baidu.dom(document).trigger('rubberselectend');
                    baidu.dom('.tang-rubberSelect').hide();

                //用户选择阶段延时0.15秒取消，使用户可以续选，雅虎交互原则。    
                },150);
            };
        },

        //防止拖拽过程中选择上文字
        unselect = function (e) {
            return e.preventDefault();
        },

        setRange = function(){
            if(opts.range){
                if(baidu.type(opts.range)=='object'){
                    range = opts.range;
                }else{

                    //传入的是selector
                    var _ele = baidu.dom(opts.range).eq(0);
                    range = _ele.offset();
                    range.bottom = range.top + _ele.outerHeight();
                    range.right = range.left + _ele.outerWidth();
                };
            };
        },

        setMask = function(){
            mask = baidu.dom('.tang-rubberSelect');
            if(!mask.size()){
                mask = baidu.dom('<div class="tang-rubberSelect" style="position:absolute;">');
            };
            mask.hide().appendTo(document.body);
        };

    //函数主逻辑开始
    setRange();
    setMask();
    doc.on('mousedown',handle);
    doc.on('mouseup',endHandle);

    return{
        target:mask,

        //设置范围
        range :function(value){
            if(!value){
                return opts.range;
            }else{
                opts.range = value;
                setRange();
                return this;
            };
        },

        //析构函数
        dispose:function(){
            
            doc.off('mousedown',handle);
            //doc.off('mousemove',ingHandle);
            doc.off('mouseup',endHandle);

            //因为其他实例中可能会用到，所以不做清除。
            //mask.remove();
            
            doc = timer = null;
            for(var k in this){
                delete this[k];
            };
            this.dispose = true;
            return null;
        }
    }
};

baidu.dom.extend({
    selectable:function(value,opts){

        var me = this,

            //初始化设置的值，挂载在实例上
            funs = {

                //默认参数及初始值
                options:{

                    //是否可用
                    enable:true,

                    //通过按下ctrl或者command间隔选择
                    intervalSelect:true
                    
                    //可以激活选择功能的范围 
                    // range:undefined,

                    //事件相关
                    // onstart:undefined,
                    // onend:undefined,
                    // ondragging:undefined,

                    //选择元素改变时触发，增加和减少都会触发
                    // onchange:undefined
                },

                //激活选择的范围，传入selector或者Object要符合{'top':123,'right':123,'bottom':123,'left':123}
                range:function(value){
                    if(value && rubberSelect && rubberSelect.dispose != true){
                        opt.range = value;
                        rubberSelect.range(value);
                        return selectable;
                    }else{
                        return opt.range;
                    };
                },

                //取消选择，恢复上次选择的结果
                cancel:function(){
                    if(lastSelected){
                        item.removeClass('tang-selectable-selected');
                        lastSelected.addClass('tang-selectable-selected');
                    }else{
                        selectable.reset();
                    }
                    return selectable;
                },

                //取消选择，恢复为一个都没选
                reset:function(){
                    lastSelected = me.find('.tang-selectable-selected');
                    item.removeClass('tang-selectable-selected');
                    return selectable;
                },
                
                //关闭选择功能
                disable:function(){
                    opt.enable = false;
                    if(rubberSelect && rubberSelect.dispose != true){
                        rubberSelect.dispose();
                        offDocEvent();
                    };
                    return selectable;
                },

                //开启选择功能
                enable:function(){
                    if(!opt.enable){
                        opt.enable = true;
                        if(rubberSelect && rubberSelect.dispose == true){
                            rubberSelect = baidu.plugin._util_.rubberSelect();
                        };
                        bindDocEvent();
                    };
                    return selectable;
                },

                //析构函数
                dispose:function(){
                    selectable.disable();
                    doc = rubberSelect = item = timer = null;
                    for(var k in selectable){
                        delete selectable[k];
                    };
                    selectable.dispose = true;
                    return null;
                },

                //设置或取得当前选中的项
                selected:function(value){
                    if(value){
                        me.find(value).addClass('tang-selectable-selected');
                        return selectable;
                    }else{
                        return me.find('.tang-selectable-selected');
                    };
                },

                //取得没有选中的值
                unselected:function(value){
                    if(value){
                        me.find(value).removeClass('tang-selectable-selected');
                        return selectable;
                    }else{
                        return item.not('.tang-selectable-selected');
                    };
                },

                //取得当前所有元素
                item:function(){
                    return item;
                },

                //取得当前选择元素的编号，或通过数组设置
                index:function(value){
                    if(baidu.type(value)=='array'){
                        item.removeClass('tang-selectable-selected');
                        for(var i = 0,num = value.length;i<num;i++){
                            item.eq(value[i]).addClass('tang-selectable-selected');
                        };
                        return selectable;
                    }else{
                        var arr = [];
                        for(var i = 0, num = item.size();i<num;i++){
                            if(item.eq(i).hasClass('tang-selectable-selected')){
                                arr.push(i);
                            };
                        };
                        return arr;
                    };
                }

            },

            doc = baidu.dom(document),

            //当前的selectable实例，自动挂载getBack方法，直接返回之前的链头
            selectable = baidu.setBack(baidu.createSingle(funs),me),

            opt = selectable.options,

            //存放rubberSelect
            rubberSelect,

            //selectable的item
            item,

            //存储上一次选择的项，cancel方法中用来还原
            lastSelected,

            //函数节流计时器
            timer,

            //按键多选的标志量，可以多选为true
            keydownMore = false,

            //初始化事件相关绑定
            bindEvent = function(){
                var evts = ['start','end','dragging','change'];
                for(var i = 0,num = evts.length;i< num; i++){
                    if( opt[ 'on'+evts[i] ] ){
                        selectable.on( evts[ i ] ,opt[ 'on'+evts[i] ] );
                    };
                };

                selectable.on('start',function(){
                    lastSelected = me.find('.tang-selectable-selected');
                });

                //支持多选功能
                selectable.on('end',function(){
                    item.removeClass('tang-selectable-selecting');
                });
            },

            handle = function(){

                //增加函数节流，防止事件频繁触发函数，影响性能
                clearTimeout(timer);
                timer = setTimeout(function(){
                    selectable.fire('dragging');
                    if(!item){return;};
                    if(!keydownMore){

                        //只能选择一次
                        for(var i = 0 , num = item.size(); i < num; i ++){
                            var _ele = item.eq(i);
                            if(_ele.isCrash(rubberSelect.target)){
                                if (!_ele.hasClass('tang-selectable-selected')) {
                                    selectable.fire('change',{target:_ele});
                                    _ele.addClass('tang-selectable-selected');
                                };
                            }else{
                                if(_ele.hasClass('tang-selectable-selected')){
                                    selectable.fire('change',{target:_ele});
                                    _ele.removeClass('tang-selectable-selected');
                                };
                            };
                        };
                    }else{

                        //按下了ctrl 或 command 键，可以多次选择
                        for(var i = 0 , num = item.size(); i < num; i ++){
                            var _ele = item.eq(i);

                            //只对选了的做判断
                            if(_ele.isCrash(rubberSelect.target) && !_ele.hasClass('tang-selectable-selecting')){
                                selectable.fire('change',{target:_ele});

                                //支持可以多次选择，判断此次碰撞是否已经选择了
                                _ele.addClass('tang-selectable-selecting');                              
                                if (!_ele.hasClass('tang-selectable-selected')) {
                                    _ele.addClass('tang-selectable-selected');
                                }else{
                                    _ele.removeClass('tang-selectable-selected');
                                };
                            };
                        };
                    };

                },3);
            },

            keyDownHandle = function(e){
                    
                //Win下Ctrl 和 Mac下 command 键
                if(e.ctrlKey || e.keyCode == 91){
                    keydownMore = true;
                };
            },

            keyUpHandle = function(e){

                //Win下Ctrl 和 Mac下 command 键
                if(!e.ctrlKey || e.keyCode == 91){
                    keydownMore = false;
                    item.removeClass('tang-selectable-selecting');
                };
            },

            fireStart = function(){
                selectable.fire('start');
            },

            fireEnd = function(){
                selectable.fire('end');
            },

            bindDocEvent = function(){
                if(opt.intervalSelect){
                    doc.on('keydown',keyDownHandle);
                    doc.on('keyup',keyUpHandle);
                };
                doc.on('rubberselecting',handle);
                doc.on('rubberselectstart',fireStart);
                doc.on('rubberselectend',fireEnd);
            },

            //统一的解绑事件
            offDocEvent = function(){
                if(opt.intervalSelect){
                    doc.off('keydown',keyDownHandle);
                    doc.off('keyup',keyUpHandle);
                };
                doc.off('rubberselecting',handle);
                doc.off('rubberselectstart',fireStart);
                doc.off('rubberselectend',fireEnd);                    
            },

            setOpt = function(opts){
                for(var k in opts){
                    opt[k] = opts[k];
                };
                if(opt.enable == false){
                    selectable.disable();
                };
                if(opt.range){
                    selectable.range(opt.range);
                };
            };

        //函数参数逻辑
        rubberSelect = baidu.plugin._util_.rubberSelect();
        switch(arguments.length){

            //没有传参，默认执行
            case 0:
                item = me.children();
            break;

            //传入一个参数
            case 1:
                if(baidu.type(value) == 'object'){

                    //此时value为options
                    item = me.children();
                    setOpt(value);
                }else{

                    //此时是selector
                    item = me.find(value);
                };

            break;

            //传入selector和options
            case 2:
                item = me.find(value);
                setOpt(opts);
            break;
        };
        bindEvent();
        bindDocEvent();
        
        //暴露getBack()方法，返回上一级TangramDom链头
        return selectable;
    }
});


 module.exports  = baidu;
