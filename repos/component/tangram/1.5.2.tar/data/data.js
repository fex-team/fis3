var baidu = require('common:static/common/lib/tangram/base/base.js');
/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 */

///import baidu;
/**
 * 对一些数据处理提供的类
 * @namespace baidu.data
 */
baidu.data = baidu.data || {};

module.exports  = baidu['data'];
