var baidu = require('common:static/common/lib/tangram/base/base.js');
/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 */

///import baidu;
/**
 * 提供一些公共工具，如log日志等
 * @namespace baidu.tools
 */
baidu.tools = baidu.tools || {};

module.exports  = baidu['tools'];
