var baidu = require('common:static/common/lib/tangram/base/base.js');
require('common:static/common/lib/tangram/uiBase/uiBase.js');
/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 */

require('common:static/common/lib/tangram/ui/Suggestion/Suggestion.js');
require('common:static/common/lib/tangram/ui/behavior/coverable/coverable.js');
/**
 * 支持背景遮罩掩盖select、flash、iframe元素
 * @name baidu.ui.Suggestion.Suggestion$coverable
 * @addon baidu.ui.Suggestion
 */
baidu.extend(baidu.ui.Suggestion.prototype, {
    coverable: true,
    coverableOptions: {}
});

baidu.ui.Suggestion.register(function(me) {

    if (me.coverable) {

        me.addEventListener('onshow', function() {
            me.Coverable_show();
        });

        me.addEventListener('onhide', function() {
            me.Coverable_hide();
        });
    }
});

module.exports  = baidu['ui']['Suggestion']['Suggestion$coverable'];
