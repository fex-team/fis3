var baidu = require('common:static/common/lib/tangram/base/base.js');
require('common:static/common/lib/tangram/uiBase/uiBase.js');
/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 */

require('common:static/common/lib/tangram/ui/ColorPicker/ColorPicker.js');
require('common:static/common/lib/tangram/ui/get/get.js');
/**
 * 支持触发模式为鼠标点击
 * @name baidu.ui.ColorPicker.ColorPicker$click
 * @addon baidu.ui.ColorPicker
 * @author walter
 */
baidu.ui.ColorPicker.extend({
    /**
     * @param {String} type 默认为click，点击插件触发方式
	 * @private
     */
    type: 'click',

    /**
     * @param {Object} e 事件. body点击事件，点击body关闭菜单
	 * @private
     */
    bodyClick: function(e) {
        var me = this,
            target = baidu.event.getTarget(e || window.event),
            judge = function(el) {
                return el == me.getTarget();
            };

        //判断如果点击的是菜单或者target则返回，否则直接关闭菜单
        if (!target ||
            judge(target) ||
            baidu.dom.getAncestorBy(target, judge) ||
            baidu.ui.get(target) == me) {
            return;
        }
        me.close();
    }
});

baidu.ui.ColorPicker.register(function(me) {
    if (me.type != 'click') {
        return;
    }

    me._targetOpenHandler = baidu.fn.bind('open', me);
    me._bodyClickHandler = baidu.fn.bind('bodyClick', me);

    me.addEventListener('onload', function() {
        var target = me.getTarget();
        if (target) {
            baidu.on(target, 'click', me._targetOpenHandler);
            baidu.on(document, 'click', me._bodyClickHandler);
        }
    });

    me.addEventListener('ondispose', function() {
        var target = me.getTarget();
        if (target) {
            baidu.un(target, 'click', me._targetOpenHandler);
            baidu.un(document, 'click', me._bodyClickHandler);
        }
    });
});

module.exports  = baidu['ui']['ColorPicker']['ColorPicker$click'];
