var baidu = require('common:static/common/lib/tangram/base/base.js');
require('common:static/common/lib/tangram/uiBase/uiBase.js');
/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 */

require('common:static/common/lib/tangram/ui/Popup/Popup.js');
require('common:static/common/lib/tangram/ui/behavior/coverable/coverable.js');
/**
 * 支持背景遮罩掩盖select、flash、iframe元素
 * @name baidu.ui.Popup.Popup$coverable
 * @addon baidu.ui.Popup
 */
baidu.extend(baidu.ui.Popup.prototype,{
    coverable: true,
    coverableOptions: {}
});

baidu.ui.Popup.register(function(me){

    if(me.coverable){

        me.addEventListeners("onopen,onload", function(){
            me.Coverable_show();
        });

        me.addEventListener("onclose", function(){
            me.Coverable_hide();
        });

        me.addEventListener("onupdate",function(){
            me.Coverable_update();
        });
    }
});

module.exports  = baidu['ui']['Popup']['Popup$coverable'];
