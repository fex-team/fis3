var baidu = require('common:static/common/lib/tangram/base/base.js');
/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 */

///import baidu;
/**
 * 提供json,xml,html的基本处理方法
 * @namespace baidu.parser
 */
baidu.parser = baidu.parser || {};

module.exports  = baidu['parser'];
