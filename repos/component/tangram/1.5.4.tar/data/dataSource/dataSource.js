var baidu = require('common:static/common/lib/tangram/base/base.js');
/**
 * Tangram
 * Copyright 2010 Baidu Inc. All rights reserved.
 * @path:data/dataSource.js
 * @author:walter
 * @version:1.0.0
 * @date:2010-11-30
 */

require('common:static/common/lib/tangram/data/data.js');
/**
 * 数据源类
 * @namespace baidu.data.dataSource
 */
baidu.data.dataSource = baidu.dataSource = baidu.data.dataSource || {};

module.exports  = baidu['data']['dataSource'];
