var baidu = require('common:static/common/lib/tangram/base/base.js');
require('common:static/common/lib/tangram/uiBase/uiBase.js');
/*
 * Tangram UI
 * Copyright 2009 Baidu Inc. All rights reserved.
 */

/**
 * 通过uiType找到UI类
 * @function
 * @grammar baidu.ui.getUI(uiType)
 * @param  {String} uiType  查找规则：suggestion -> baidu.ui.Suggestion，toolbar-spacer -> baidu.ui.Toolbar.Spacer.
 * @return {object} UI类
 * @author berg
 */
baidu.ui.getUI = function(uiType){
    var uiType = uiType.split('-'),
        result = baidu.ui,
        len = uiType.length,
        i = 0;

    for (; i < len; i++) {
        result = result[uiType[i].charAt(0).toUpperCase() + uiType[i].slice(1)];
    }
    return result;
};

module.exports  = baidu['ui']['getUI'];
