var baidu = require('common:static/common/lib/tangram/base/base.js');
require('common:static/common/lib/tangram/uiBase/uiBase.js');
/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 */

require('common:static/common/lib/tangram/ui/Modal/Modal.js');
require('common:static/common/lib/tangram/ui/behavior/coverable/coverable.js');
/**
 * 支持背景遮罩掩盖select、flash、iframe元素
 * @name baidu.ui.Modal.Modal$coverable
 * @addon baidu.ui.Modal
 */
baidu.extend(baidu.ui.Modal.prototype,{
    coverable: true,
    coverableOptions: {}
});

baidu.ui.Modal.register(function(me){

    if(me.coverable){

        if(!baidu.browser.isWebkit && !baidu.browser.isGecko){
            me.addEventListener("onload", function(){
                me.Coverable_show();
            });

            me.addEventListeners("onshow,onupdate",function(){
                me.Coverable_update();
            });

            me.addEventListener("onhide", function(){
                me.Coverable_hide();
            })
        }
    }
});

module.exports  = baidu['ui']['Modal']['Modal$coverable'];
