var baidu = require('common:static/common/lib/tangram/base/base.js');
require('common:static/common/lib/tangram/uiBase/uiBase.js');
/*
 * Tangram UI
 * Copyright 2009 Baidu Inc. All rights reserved.
 * 
 * path: baidu/ui/Base/getParent.js
 * author: berg
 * version: 1.0.0
 * date: 2010/12/02
 */

/**
 * 获取UI控件的父控件
 * @memberOf baidu.ui.Base.prototype
 * @return {UI} 父控件
 */
baidu.ui.Base.getParent = function(){
    return this._parent || null;
};

module.exports  = baidu['ui']['Base']['getParent'];
