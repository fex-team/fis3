var baidu = require('common:static/common/lib/tangram/base/base.js');
require('common:static/common/lib/tangram/uiBase/uiBase.js');
/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 */

require('common:static/common/lib/tangram/ui/Tooltip/Tooltip.js');
require('common:static/common/lib/tangram/ui/get/get.js');
/**
 * 支持单击隐藏显示Tooltip
 * @name  baidu.ui.Tooltip.Tooltip$click
 * @addon baidu.ui.Tooltip
 */
baidu.ui.Tooltip.register(function(me) {
    
    if (me.type == 'click') {

        //onload时绑定显示方法
        me.addEventListener("onload",function(){
            baidu.each(me.target,function(target){
                baidu.on(target, 'click', showFn); 
            });
        });

        //dispose时接触事件绑定
        me.addEventListener("ondispose",function(){
            baidu.each(me.target,function(target){
                baidu.un(target, 'click', showFn); 
            });

            baidu.un(document, 'click', hideFn);
        });

        //tooltip打开时，绑定和解除方法
        me.addEventListener('onopen', function(){
            baidu.un(me.currentTarget, 'click', showFn);
            baidu.on(me.currentTarget, 'click', hideFn);
            baidu.on(document, 'click', hideFn);
        });

        //tooltip隐藏时，绑定和解除方法
        me.addEventListener('onclose', function(){
            
            baidu.on(me.currentTarget, 'click', showFn);
            baidu.un(me.currentTarget, 'click', hideFn);
            baidu.un(document, 'click', hideFn);

        });

        //显示tooltip
        function showFn(e){
            me.open(this);
            
            //停止默认事件及事件传播
            baidu.event.stop(e || window.event);
        }

        //隐藏tooltip
        function hideFn(e){
            var target = baidu.event.getTarget(e || window.event),
                judge = function(el){
                    return me.getBody() == el;
                };
            if(judge(target) || baidu.dom.getAncestorBy(target, judge) || baidu.ui.get(target) == me){
                return;
            }

            me.close();
            //停止默认事件及事件传播
            baidu.event.stop(e || window.event);
        }
    }
});

module.exports  = baidu['ui']['Tooltip']['Tooltip$click'];
