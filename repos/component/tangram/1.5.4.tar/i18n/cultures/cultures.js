var baidu = require('common:static/common/lib/tangram/base/base.js');
/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 */
require('common:static/common/lib/tangram/i18n/i18n.js');
baidu.i18n.cultures = baidu.i18n.cultures || {};
module.exports  = baidu['i18n']['cultures'];
