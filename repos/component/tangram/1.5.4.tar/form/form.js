var baidu = require('common:static/common/lib/tangram/base/base.js');
/*
 * Tangram
 * Copyright 2011 Baidu Inc. All rights reserved.
 */

///import baidu;
/**
 * 和表单相关的数据验证
 * @namespace baidu.form
 */
baidu.form = baidu.form || {};
module.exports  = baidu['form'];
