var baidu = require('common:static/common/lib/tangram/base/base.js');


baidu.plugin = baidu.plugin || {};
baidu.plugin._util_ = baidu.plugin._util_ || {};

baidu.plugin._util_.drag = function(selector){

    var timer,

        doc = baidu.dom(document),

        //只对第一个值操作
        ele = baidu.dom(selector).eq(0),

        //拖拽前的offset值
        offset = ele.offset(),

        //相对宽度和高度
        width,height,

        //限定拖动范围，如果有值，则为 {top:,right:,bottom:,left:}
        range,

        //跟随鼠标移动
        move = function(ele,x,y){
            if(range){

                //优化超速移动鼠标的情况，兼容有border的情况
                x = Math.min(range.right - range.width, Math.max(range.left, x));
                y = Math.min(range.bottom - range.height, Math.max(range.top, y));
            };

            //相对屏幕设置位置
            ele.offset({'left':x,'top':y});

            //对全局派发事件
            doc.trigger('dragging');
        },

        handle = function(event){

            //增加函数节流，防止事件频繁触发函数，影响性能
            if(timer){return};
            timer = setTimeout(function(){
                var o = ele.offset();
                !width && (width = event.pageX - o.left);
                !height && (height = event.pageY - o.top);
                move(ele,event.pageX - width,event.pageY - height);
                timer = null;
            },16);
        },

        //防止拖拽过程中选择上文字
        unselect = function (e) {
            return e.preventDefault();
        },

        onEvent = function(){

            //修正拖曳过程中页面里的文字会被选中
            doc.on('selectstart',unselect);
            doc.on('mousemove',handle);

            //设置鼠标粘滞
            if (ele[0].setCapture) {
                ele[0].setCapture();
            } else if (window.captureEvents) {
                window.captureEvents(Event.MOUSEMOVE|Event.MOUSEUP);
            };

            //清除鼠标已选择元素
            if(document.selection){
                document.selection.empty && document.selection.empty();
            }else if(window.getSelection){
                window.getSelection().removeAllRanges();
            };
        },

        offEvent = function(){

            //防止最后一次的触发
            clearTimeout(timer);

            //解除鼠标粘滞
            if (ele[0].releaseCapture) {
                ele[0].releaseCapture();
            } else if (window.releaseEvents) {
                window.releaseEvents(Event.MOUSEMOVE|Event.MOUSEUP);
            };
            doc.off('mousemove',handle);
            doc.off('selectstart',unselect);
        };

    doc.trigger('dragstart',{target:ele});
    onEvent();

    return {
        target:ele,
        disable:function(){
            offEvent();
            width = height = null;
            doc.trigger('dragend');
            return this;
        },
        enable:function(){
            doc.trigger('dragstart');
            onEvent();
            return this;
        },
        range:function(value){
            if(value === undefined){
                return range;
            };
            var uRange = value, el;
            if(baidu.type(value) !== 'object'){
                el = baidu.dom(value).eq(0);
                uRange = el.offset();
                uRange.right = uRange.left + el.outerWidth();
                uRange.bottom = uRange.top + el.outerHeight();
            };
            range = baidu.extend({
                left: Number.MIN_VALUE,
                top: Number.MIN_VALUE,
                right: Number.MAX_VALUE,
                bottom: Number.MAX_VALUE,
                width: ele.outerWidth(),
                height: ele.outerHeight()
            }, uRange);
            return this;
        },

        //取消上一次拖拽
        cancel:function(){
            ele.offset(offset);
            return this;
        },

        //析构函数
        dispose:function(){
            offEvent();
            width = height = doc = ele = offset = range = null;
            for(var k in this){
                delete this[k];
            };
            this.dispose = true;
            return null;
        }
    }
};

baidu.dom.extend({
    isCrash : function(selector,strict){
        if(!arguments.length){ 
            return false; 
        };

        //传入的元素，get first
        var me = this,
            ele = baidu.dom(selector).eq(0),
            o = ele.offset(),
            w = ele.outerWidth(),
            h = ele.outerHeight(),
            num = me.size(),

            //检测算子，传入四个值比较，strict（是否严格）
            check = function(top,right,bottom,left,strict){
                if(strict){

                    //严格模式，一定要在容器内
                    if((o.top>=top)&&((o.top+h)<=bottom)&&(o.left>=left)&&((o.left+w)<=right)){
                        return true;
                    };

                }else{

                    //非严格模式，有碰撞或交集即可
                    if(((o.top+h)>=top)&&(o.top<=bottom)&&((o.left+w)>=left)&&(o.left<=right)){
                        return true;
                    };
                };
            };

        for(var i = 0; i < num; i++ ){
            var _ele = me.eq(i),
                _o = _ele.offset(),
                _w = _ele.eq(i).outerWidth(),
                _h = _ele.eq(i).outerHeight();

            if(check(_o.top,_o.left+_w,_o.top+_h,_o.left,strict)){
                return true;
            };
        };

        return false;
    }
});

// //检测两区域是否碰撞
// check(a1,a2){
//     if(a1.top>a2.bottom||a1.bottom<a2.top||a1.left>a2.right||a1.right<a2.left){
//         return false;
//     }else{
//         return true;
//     };
// };

baidu.dom.extend({
    draggable:function(value,opts){

        var me = this,

            //存放drag实例，drag.target是当前的拖拽元素
            drag,

            //存放当前拖拽元素
            dragEle,

            //drag enter的元素列表，在drag leave中会监测
            dragEnter = {},

            //最初的位置
            _offset,

            //关注的元素
            focusEle,

            //初始化设置的值，挂在在实例上
            funs = {

                //默认参数及初始值
                options:{
                    enable:true 
                    // range:undefined,
                    // endOf:undefined,
                    // zIndex:undefined,
                    // focus:undefined,

                    // //事件相关
                    // onstart:undefined,
                    // onend:undefined,
                    // onenter:undefined,
                    // onleave:undefined,
                    // ondragging:undefined
                },

                //可拖拽的范围，传入Object要符合{'top':123,'right':123,'bottom':123,'left':123}
                range:function(value){
                    switch(arguments.length){
                        
                        //不传参，get方法
                        case 0:
                            return opt.range;
                        break;

                        //传一个参数
                        case 1:

                            //value是selector
                            opt.range = value;
                        break;
                    };
                    return draggable;
                },

                //最终要拖拽到
                endOf:function(value){
                    switch(arguments.length){
                        
                        //不传参，get方法
                        case 0:

                            //内部endOf方法。
                            if(baidu.type(opt.endOf)=='object'){

                                //endOf的范围是Object,{'top':123,'right':123,'bottom':123,'left':123}
                                if(!dragEle.w){
                                    dragEle.w = dragEle.outerWidth();
                                    dragEle.h = dragEle.outerHeight();
                                };
                                var o = dragEle.offset(),
                                    eo = opt.endOf;
                               
                                if( o.left >= eo.left && o.left + dragEle.w <= eo.right && o.top >= eo.top && o.top + dragEle.h <= eo.bottom){
                                }else{
                                    draggable.cancel();
                                };
                            }else{

                                //endOf的范围是selector
                                if(!baidu.dom(opt.endOf).isCrash(drag.target,true)){
                                    draggable.cancel();
                                };                                
                            };
                            return opt.endOf;
                        //break;

                        //传一个参数
                        case 1:

                            //value是selector或者是object;
                            opt.endOf = value;
                        break;
                    };
                    return draggable;
                },

                //获取当前正在被拖拽的元素，或者上一次被拖拽的元素
                item:function(){
                    return dragEle;
                },

                //显示层级
                zIndex:function(value){
                    if(typeof value != 'undefined'){
                        opt.zIndex = value;
                        me.css('z-index',value);
                        return draggable;
                    }else{
                        return opt.zIndex;
                    };
                },

                //重置方法，恢复到最初
                reset:function(){
                    if(drag){
                        dragEle.offset(_offset);
                    };
                    return draggable;
                },

                //取消拖拽，回到上一次
                cancel:function(){
                    if(drag){
                        drag.cancel();
                    };
                    return draggable;
                },

                //关闭拖拽
                disable:function(){
                    if(opt.enable){
                        opt.enable = false;
                        if(value && baidu.type(value)!='object'){
                            me.find(value).css('cursor','default');
                        }else{
                            me.css('cursor','default');
                        };
                    };
                    return draggable;
                },

                //开启拖拽
                enable:function(){
                    if(!opt.enable){
                        opt.enable = true;
                        if(value && baidu.type(value)!='object'){
                            me.find(value).css('cursor','move');
                        }else{
                            me.css('cursor','move');
                        };
                    };
                    return draggable;
                },

                //析构函数
                dispose:function(){
                    draggable.disable();
                    if(drag && drag.dispose != true){
                        drag.dispose();
                    };

                    //此处删除所有事件，如果用户有其他事件可能会一起删除。
                    //TODO：后续修改下。
                    me.off('mousedown');
                    drag = dragEle = focusEle = doc = opt = null;
                    for(var k in draggable){
                        delete draggable[k];
                    };
                    draggable.dispose = true;
                    return null;
                }
            },
            doc = baidu.dom(document),

            //当前的draggable实例，自动挂载getBack方法，直接返回之前的链头
            draggable = baidu.setBack(baidu.createSingle(funs),me),

            opt = draggable.options,

            //拖拽执行（主逻辑），mousedown时触发
            handle = function(e){
                //拖拽是否可用
                //表单不可拖拽，原因是如果父元素可拖拽，子元素是表单元素，在mousedown的情况下改变父元素的position值，在ff和ie下会导致子元素永远取不到焦点，无法在表单中输入内容
                if(~'input|textarea|select|option'.indexOf(e.target.tagName.toLowerCase())
                    || !opt.enable){
                    return;
                }
                //实例一个drag
                drag && drag.dispose();
                drag = baidu.plugin._util_.drag(e.currentTarget);
                dragEle = drag.target;
                dragEle.addClass('tang-draggable-dragging');
                draggable.fire('start',{target:dragEle,pageX:e.pageX,pageY:e.pageY});
                if(!_offset){
                    _offset = dragEle.offset();
                };

                //限制了范围
                if(opt.range){
                    drag.range(opt.range);
                };

                //是否有层级设置
                if(opt.zIndex){
                    draggable.zIndex(opt.zIndex);
                };
                                
                doc.on('mouseup',endHandle);
                doc.on('dragging',ingHandle);
            },

            //拖拽停止
            endHandle = function(e){

                //是否到达拖拽目的地
                if(opt.endOf){
                    draggable.endOf();
                };
                dragEle.removeClass('tang-draggable-dragging');
                drag.disable();
                draggable.fire('end');
                doc.off('mouseup',endHandle);
                doc.off('dragging',ingHandle);
            },

            //拖拽中
            ingHandle = function(e){
                draggable.fire('dragging');
                enterAndLeave();
            },

            //初始化事件相关绑定
            bindEvent = function(){
                var evts = ['start','end','dragging','enter','leave'];
                for(var i = 0;i<evts.length; i++){
                    if( opt[ 'on'+evts[i] ] ){
                        draggable.on( evts[ i ] ,opt[ 'on'+evts[i] ] );
                    };
                };
            },

            //根据第二个selector，设置拖拽激活区，只对该区域监听mousedown事件
            setItem = function(){
                me.find(value).css('cursor','move');
                me.on('mousedown',function(e){
                    if(baidu.dom(e.currentTarget).contains(e.target)){
                        handle(e);
                    };
                });
            },

            //当用户传入options时，处理逻辑
            setOpt = function(opts){
                for(var k in opts){
                    opt[k] = opts[k];
                };
                if(opt.focus){

                    //要去掉自己本身
                    focusEle = baidu.dom(opt.focus).not(me);
                };
                if(opt.zIndex){
                    draggable.zIndex(opt.zIndex);
                };
                if(opt.enable == false){
                    opt.enable = true;
                    draggable.disable();
                };
                bindEvent();   
            },

            //实现draggable中的'enter'和‘leave’事件
            enterAndLeave = function(){
                if( opt.focus  && (opt.onenter||opt.onleave) ){

                    //存储当前enter的元素
                    var _dragEnter = {};

                    for(var i = 0,num = focusEle.size(); i < num; i++){
                        
                        var _e = focusEle.eq(i),
                            id = baidu.id(_e.get(0));

                        if( _e.isCrash(dragEle) ){

                            //观察对象的改变来触发
                            if(!dragEnter[id]){
                                dragEnter[id] = _e.get(0);
                                draggable.fire('enter',{'target':dragEnter[id]});
                            };
                            _dragEnter[id] = _e.get(0);
                        };

                    };

                    //判断是否触发leave事件
                    for(var k in dragEnter){
                        if(dragEnter[k] && !_dragEnter[k]){
                            draggable.fire('leave',{'target':dragEnter[k]});
                            dragEnter[k] = null;
                        };
                    };
                };
            };

        //函数参数逻辑
        switch(arguments.length){

            //没有传参，默认执行
            case 0:
                me.css('cursor','move').on('mousedown',handle);
            break;

            //传入一个参数
            case 1:
                if( baidu.type(value) == 'object' ){

                    //value是options
                    me.css('cursor','move').on('mousedown',handle);
                    setOpt(value);
                }else{
                
                    //value是selector
                    setItem();
                }
            break;

            //传入selector和options
            case 2:

                //value是selector
                setItem();
                setOpt(opts);
            break;
        };

        //暴露getBack()方法，返回上一级TangramDom链头
        return draggable;
    }
});

baidu.dom.extend({
    sortable : function(value,opts){

        var me = this,
            argsNum = arguments.length,

            //每一个可以被拖拽的项
            item,

            //每个元素的相关值
            itemAttr = [],

            //当前的draggable对象
            draggable,

            //当前被拖拽的项
            dragEle,

            //当前拖拽元素的相关属性信息
            dragEleAttr = {},

            //克隆的拖拽元素
            dragEleClone,
            dragEleCloneAttr = {},

            //当前sortable内的HTML，为了能够完美实现reset方法
            htmlReset = '',

            //每次变化后sortable内的HTML，为了能够完美实现cancel方法
            htmlCancel = '',
            htmlTemp = '',

            //初始化设置的值，挂在在实例上
            funs = {

                //默认参数及初始值
                options:{
                    enable:true 
                    // range:undefined,

                    //事件相关
                    // onstart:undefined,
                    // onend:undefined,
                    // ondragging:undefined,
                    // onchange:undefined
                },

                //可拖拽的范围，传入Object要符合{'top':123,'right':123,'bottom':123,'left':123}
                range:function(value){
                    switch(arguments.length){
                        
                        //不传参，get方法
                        case 0:
                            return opt.range;
                        break;

                        //传一个参数
                        case 1:

                            //value是selector
                            opt.range = value;
                            draggable.range(value);
                        break;
                    };
                    return sortable;
                },

                //取出可以被拖拽的项，顺序为新顺序
                item:function(){
                    return me.find('.tang-sortable-item');
                },

                //索引
                index:function(value){
                    if(value == 'set'){

                        //set方法，内部接口
                        for(var i = 0,num = item.size();i<num;i++){
                            item.eq(i).data('sortable-id',i);
                        };
                        return sortable;
                    }else{
                        var index = [],
                            _item = me.find('.tang-sortable-item');
                        for(var i = 0,num = _item.size();i<num;i++){
                            index.push(_item.eq(i).data('sortable-id'));
                        };
                        return index;
                    };
                },

                //取消拖拽，回到上一次
                cancel:function(){
                    me.html(htmlCancel);
                    init();
                    (opt.enable == false) && sortable.disable();
                    return sortable;
                },

                //重置拖拽
                reset:function(){
                    me.html(htmlReset);
                    init();
                    (opt.enable == false) && sortable.disable();
                    return sortable;
                },

                //关闭拖拽
                disable:function(){
                    opt.enable = false;
                    item.removeClass('tang-sortable-item');
                    draggable.disable();
                    return sortable;
                },

                //开启拖拽
                enable:function(){
                    if(!opt.enable){
                        opt.enable = true;
                        draggable.enable();
                    };
                    return sortable;
                },

                //析构函数
                dispose:function(){
                    sortable.disable();
                    draggable.dispose();
                    doc = opt = me = item = itemAttr = dragEle = dragEleAttr = dragEleClone = dragEleCloneAttr = null;
                    for(var k in sortable){
                        delete sortable[k];
                    };
                    sortable.dispose = true;
                    return null;
                }
            },

            doc = baidu.dom(document),

            //当前的sortable实例，自动挂载getBack方法，直接返回之前的链头
            sortable = baidu.setBack(baidu.createSingle(funs),me),

            opt = sortable.options,

            //初始化事件相关绑定
            bindEvent = function(){
                var evts = ['start','end','dragging','change'];
                for(var i = 0;i<evts.length; i++){
                    if( opt[ 'on'+evts[i] ] ){
                        sortable.on( evts[ i ] ,opt[ 'on'+evts[i] ] );
                    };
                };

                //在cancel和reset方法中，这些事件会被重绑，所以在这先清除。
                draggable.off('start',handle);
                draggable.off('dragging',ingHandle);
                draggable.off('end',endHandle);

                draggable.on('start',handle);
                draggable.on('dragging',ingHandle);
                draggable.on('end',endHandle);
            },

            getItemAttr = function(){
                itemAttr = [];
                for(var i = 0 , num = item.size(); i< num ; i++){
                    var ele = item.eq(i),
                        w = ele.outerWidth(),
                        h = ele.outerHeight(),
                        o = ele.offset(),

                        //TODO:如果想支持非列表类型，如块类型的并排横着摆放，在此加入left和right判断。
                        // left = {},
                        // right = {},
                        up = {top:o.top,bottom:o.top+h/2,left:o.left,right:o.left+w},
                        down = {top:o.top+h/2,bottom:o.top+h,left:o.left,right:o.left+w};
                    itemAttr.push({id:i,target:ele,up:up,down:down});
                };
            },

            //判断是否碰撞，返回当前碰撞的方位false,up,down,both
            checkCrash = function(area1,area2){
                var up = isCrash(area1.up,area2),
                    down = isCrash(area1.down,area2);
                if(up && down){
                    return 'both';
                }else if(up && !down){
                    return 'up';
                }else if(down && !up){
                    return 'down';
                }else{
                    return false;
                };
            },

            //检测两区域是否碰撞
            isCrash = function(a1,a2){
                if(a1.top>a2.bottom||a1.bottom<a2.top||a1.left>a2.right||a1.right<a2.left){
                    return false;
                }else{
                    return true;
                };
            },

            handle = function(e){
                getItemAttr();
                dragEle = e.target;
                dragEleAttr = {
                    id:dragEle.data('sortable-id'),
                    w:dragEle.outerWidth(),
                    h:dragEle.outerHeight(),
                    zIndex:dragEle.css('z-index')
                };
                sortable.fire('start');
                htmlTemp = me.html().replace(/\stang-draggable-dragging/g,'');

                //清除掉draggable附加的className
                dragEleClone = dragEle.clone();

                //TODO：以后可以考虑根据需求开放clone这个元素的样式
                dragEleClone.addClass('tang-sortable-clone');
                dragEleClone.removeClass('tang-draggable-dragging tang-sortable-item');

                dragEle.after(dragEleClone);
                dragEleClone.css('visibility','hidden');

                //TODO:这里的z-index不应该被硬编码的，需要判断下周边的z-index来设定。
                dragEle.css({'position':'absolute','z-index':200});
                var o = dragEleClone.offset();
                dragEleCloneAttr.left = o.left;
                dragEleCloneAttr.top = o.top;
            },

            ingHandle = function(){

                //这段监听的dragging，dragging已经被函数节流过了。
                var index,position;
                var o = dragEle.offset();
                dragEleAttr.top = o.top;
                dragEleAttr.left = o.left;
                dragEleAttr.bottom = o.top + dragEleAttr.h;
                dragEleAttr.right = o.left + dragEleAttr.w;
                for(var i = 0 ,num = itemAttr.length;i<num;i++){
                    if(itemAttr[i].id != dragEleAttr.id ){
                        position = checkCrash(itemAttr[i],dragEleAttr);
                        if(position == 'up'){
                            itemAttr[i].target.before(dragEleClone);
                        }else if(position == 'down'){
                            itemAttr[i].target.after(dragEleClone);
                        }else if(position == 'both'){
                            //itemAttr[i].target.before(dragEleClone);
                        }else{

                        };
                    };
                };
                sortable.fire('dragging');
            },

            endHandle = function(){
                var o = dragEleClone.offset();
                
                //克隆的元素在原位
                if(o.left == dragEleCloneAttr.left && o.top == dragEleCloneAttr.top){
                }else{
                    htmlCancel = htmlTemp;
                    sortable.fire('change');
                    dragEleClone.after(dragEle);
                };
                dragEle.css({'position':'static',left:'',top:'','z-index':dragEleAttr.zIndex});
                dragEleClone.remove();
                dragEleClone = null;
                sortable.fire('end');
            },

            setOpt = function(opts){
                for(var k in opts){
                    opt[k] = opts[k];
                };
                (opt.enable == false) && sortable.disable();
            },

            //函数主逻辑
            init = function(){

                //函数参数逻辑
                switch(argsNum){

                    //没有传参，默认执行
                    case 0:
                        item = me.children();
                    break;

                    //传入一个参数
                    case 1:
                        if( baidu.type(value) == 'object' ){
                            item = me.children();

                            //value是options
                            setOpt(value);
                        }else{
                        
                            //value是selector
                            item = me.find(value);
                        };
                    break;

                    //传入selector和options
                    case 2:

                        //value是selector
                        item = me.find(value);
                        setOpt(opts);
                    break;
                };
                item.addClass('tang-sortable-item');
                draggable = baidu(item).draggable().range(opt.range);
                sortable.index('set');
                bindEvent();
            };

        init();
        htmlReset = htmlCancel = me.html();

        //暴露getBack()方法，返回上一级TangramDom链头
        return sortable;
    }
});


 module.exports  = baidu;
