alert('photo:widget/ui/b/b.js');
require.async('../respClick/respClick.js', function(resp) {
    resp.hello();
});