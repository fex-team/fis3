alert('photo:widget/ui/a/a.js');
require('../b/b.js');