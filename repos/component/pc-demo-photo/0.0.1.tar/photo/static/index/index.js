require('common:widget/ui/require_c/require_c.js');
require.async('common:widget/ui/pkg_1.js', function() {

});
require.async('common:widget/ui/pkg_2.js', function() {

});

require('common:widget/ui/pkg_sync_1.js');