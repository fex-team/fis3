
module.exports = {
    hello: function() {
        alert('hello world!');
    }
};