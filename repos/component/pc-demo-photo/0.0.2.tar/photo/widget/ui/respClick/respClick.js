
exports.hello = function() {
    alert('Hello World');
};

require('../a/a.js');