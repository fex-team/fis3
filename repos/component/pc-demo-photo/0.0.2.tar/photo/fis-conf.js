fis.config.merge({
    namespace: 'photo',
    pack: {
        '/static/photo/aio.js': [
            "**.js"
        ]
    }
});
