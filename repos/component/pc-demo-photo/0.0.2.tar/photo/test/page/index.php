<?php
$fis_data = array(
    'menu' => array(
        'list' => array(
            array(
                'href'=> '/list#a',
                'a' => 'list#a'
            ),
            array(
                'href' => '/list#b',
                'a' => 'list#b'
            ),
            array(
                'href' => '/list#c',
                'a' => 'list#c'
            )
        )
    )
);