require('common:widget/lib/gmu/navigator.default/navigator.default.js');
module.exports = require('common:widget/lib/gmu/navigator/iscroll/iscroll.js');