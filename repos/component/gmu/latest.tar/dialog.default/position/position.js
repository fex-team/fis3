require('common:widget/lib/gmu/dialog.default/dialog.default.js');
module.exports = require('common:widget/lib/gmu/dialog/position/position.js');