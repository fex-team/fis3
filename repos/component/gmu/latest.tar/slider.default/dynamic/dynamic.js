require('common:widget/lib/gmu/slider.default/slider.default.js');
module.exports = require('common:widget/lib/gmu/slider/dynamic/dynamic.js');