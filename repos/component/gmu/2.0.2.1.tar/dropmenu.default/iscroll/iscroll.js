require('common:widget/lib/gmu/dropmenu.default/dropmenu.default.js');
module.exports = require('common:widget/lib/gmu/dropmenu/iscroll/iscroll.js');