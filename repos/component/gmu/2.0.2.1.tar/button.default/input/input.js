require('common:widget/lib/gmu/button.default/button.default.js');
module.exports = require('common:widget/lib/gmu/button/input/input.js');