require('common:widget/lib/gmu/refresh.default/refresh.default.js');
module.exports = require('common:widget/lib/gmu/refresh/iOS5/iOS5.js');