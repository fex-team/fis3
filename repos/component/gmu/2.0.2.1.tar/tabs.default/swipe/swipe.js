require('common:widget/lib/gmu/tabs.default/tabs.default.js');
module.exports = require('common:widget/lib/gmu/tabs/swipe/swipe.js');