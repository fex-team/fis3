var comp = require('../comp/comp.js');
console.log(comp);
exports.name = 'list';
console.log('list loaded');