exports.name = 'comp';
console.log('comp loaded');