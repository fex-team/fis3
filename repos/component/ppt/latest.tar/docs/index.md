# FIS PPT

```javascript
fis.config.merge({
    modules : {
        parser : {
            md : 'marked'
        }
    }
});
```

基于 [reveal-js](http://lab.hakim.se/reveal-js/) + [fis-parser-marked](https://github.com/fouber/fis-parser-marked)