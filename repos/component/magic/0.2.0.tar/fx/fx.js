var baidu = require('common:static/common/lib/tangram/base/base.js');
var magic = require('common:static/common/lib/magic/magic.js');
/*
 * Tangram
 * Copyright 2009 Baidu Inc. All rights reserved.
 */

///import baidu;
/**
 * 提供各种公共的动画功能
 * @namespace baidu.fx
 */
baidu.fx = baidu.fx || {} ;

module.exports  = magic['fx'];
