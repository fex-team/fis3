var baidu = require('common:static/common/lib/tangram/base/base.js');
var magic = require('common:static/common/lib/magic/magic.js');
/*
 * Tangram
 * Copyright 2011 Baidu Inc. All rights reserved.
 * 
 * version: 2.0
 * date: 2011/12/15
 * author: meizz
 */

require('common:static/common/lib/magic/control/Layer/Layer.js');
require('common:static/common/lib/magic/Background/$styleBox/$styleBox.js');
///import baidu.string.format

/**
 * 遮罩层
 *
 * @namespace magic.Tooltip
 * @author meizz

 * @param	{JSON}			options 	参数设置
 * @config	{Boolean}		coverable	[r/w]对<select>、<object>、Flash 是否采取遮盖处理？
 * @config	{String}		bgColor 	[r/w]遮罩层背景色
 * @config  {Number}		opacity 	[r/w]背景层透明度，取值 0-1
 * @config  {HTMLElement}	container 	[r/w]遮罩层的容器，默认为 document.body
 */
magic.control.Tooltip = baidu.lang.createClass(function(options){
	//Layer里设置了width,height。
	magic.control.Layer.call(this, options);
    this.offsetX = 0;
    this.offsetY = 0;
	baidu.object.extend(this, options);
	
},{
    'type' : 'magic.control.Tootip',
    'superClass' : magic.control.Layer
}).extend({
    
    'attach' : function(element) {
        if(element = baidu.dom.g(element)) {
            this._host = element;
            this.show();
        }
    },
    
    /**
     * 向弹出层写入内容，支持HTML
     * @param   {String}    content 将要写入的内容
     */
    'setContent' : function(content){
        this.getElement("content").innerHTML = content;
    },
    
    /**
     * 对弹出层重新定位，主要是应对页面resize时绑定的目标元素位置发生改变时重定位
     * @param   {JSON|Array}    position    [可选]{top, left}|[top, left]
     */
    'reposition' : function(position){
        var me = this;
        !position && me._host && (position = baidu.dom.getPosition(me._host));

        if (position) {
            me.top = position.top + me.offsetY + me._host.offsetHeight;
            me.left= position.left+ me.offsetX;
        }
        me.setPosition([me.left, me.top]);
    },

    /**
     * 弹出层的定位
     * @param   {JSON}  position    {left, top}|[left, top]
     */
    'setPosition' : function(position){
        this.setTop(position.top || position[1]);
        this.setLeft(position.left || position[0]);
    },
    
    'setTop' : function(top) {
        baidu.dom.setPixel(this.getElement(), 'top', (this.top=top));
    },
    
    'setLeft' : function(left) {
        baidu.dom.setPixel(this.getElement(), 'left', (this.left=left));
    }  
});
module.exports  = magic['control']['Tooltip'];
