var baidu = require('common:static/common/lib/tangram/base/base.js');
var magic = require('common:static/common/lib/magic/magic.js');
/*
 * Tangram
 * Copyright 2011 Baidu Inc. All rights reserved.
 * 
 * version: 2.0
 * date: 2011/11/28
 * author: 
 */

require('common:static/common/lib/magic/setup/setup.js');
require('common:static/common/lib/magic/Pager/Pager.js');
/**
 * 由HTML反向创建 Pager
 *
 * @namespace magic.setup.pager
 * @author xiadengping
 */
magic.setup.pager = function(el, options){
    el = baidu.dom.g(el);
	var instance = magic.setup(el, magic.Pager);
	instance.render(el);
	return instance;
};
module.exports  = magic['setup']['pager'];
