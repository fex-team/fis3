var baidu = require('common:static/common/lib/tangram/base/base.js');
var magic = require('common:static/common/lib/magic/magic.js');
/*
 * Tangram
 * Copyright 2012 Baidu Inc. All rights reserved.
 * 
 * version: 1.0
 * date: 2012/12/20
 * author: robin
 */

require('common:static/common/lib/magic/setup/setup.js');
require('common:static/common/lib/magic/control/Tooltip/Tooltip.js');
require('common:static/common/lib/magic/Background/Background.js');
require('common:static/common/lib/magic/Background/$styleBox/$styleBox.js');
/**
 * @description 在页面已有 html 结构的基础上创建提示框组件
 * @name magic.setup.tooltip
 * @function
 * @grammar  magic.setup.tooltip(el,options)
 * @param {String|HTMLElement} el 容器，ID或者HTML元素 
 * @param {Object} options 控制选项
 * @param {Boolean} options.autoHide 是否自动隐藏, 如果为true,则会在scroll,resize,click,keydown(escape)事件下隐藏，默认值为true。
 * @param {Boolean} options.hasCloseBtn 是否可以通过右上角X来关闭提示。默认值为true。
 * @param {Boolean} options.hasArrow 是否显示箭头。默认值为true。
 * @param {Number} options.offsetX 定位时的偏移量，X方向。
 * @param {Number} options.offsetY 定位时的偏移量，Y方向。
 * @param {Array} options.target 需要提示的节点。(必选)
 * @param {Function|String} options.content 自定义内容定制。若为Function,则参数为Tangram对象(目标节点)。默认值为空。
 * @param {String} options.showEvent 提示显示的动作，默认值为mouseover,focus。
 * @param {String} options.hideEvent 提示隐藏的动作，默认值为mouseout,blur。
 * @param {String} options.position 设置tooltip的位置，值为top|bottom|left|right，默认值为bottom。
 * @param {Number|Percent} options.arrowPosition 设置arrow的位置，如果是上、下方位的话，都相对于左边的距离。如果是左、右方位的话，都相对于上面的距离。如果该值不存在，则自动计算提示框位置离目标节点中间最靠近的位置。
 * @example 
 * var tooltip = new magic.setup.tooltip(el, {});
 * @return {magic.control.Tooltip} magic.control.Tooltip 实例
 */
magic.setup.tooltip = function(el, options){
    if(baidu.type(el) === "string"){
        el = '#' + el;
    }
    el = baidu(el)[0];
    var opt = options || {};
    opt.target || (opt.target = document.body);

    /**
     *@description tooltip 组件 setup 模式的实例对象
     *@instace
     *@name magic.setup.tooltip!
     *@superClass magic.control.Tooltip
     *@return {instace} magic.control.Tooltip 实例对象
     */
    var instance = magic.setup(el, magic.control.Tooltip, opt),
        container = instance.getElement();

    container.style.zIndex = baidu.global.getZIndex("popup");

    instance.background = new magic.Background({coverable:true, styleBox:true});
    instance.background.render(container); 
    instance.on("dispose", function(){
        instance.background.$dispose();
    });

    instance.$mappingDom("", baidu(".magic-tooltip", container)[0]);
    instance.$mappingDom("close", baidu(".magic-tooltip-close", container)[0]);
    instance.$mappingDom("closeBtn", baidu("a", instance.getElement("close"))[0]);
    instance.$mappingDom("content", baidu(".magic-tooltip-content", container)[0]);
    instance.$mappingDom("arrow", baidu(".magic-tooltip-arrow", instance.getElement("body"))[0]);
    instance._isShow = true;
    instance.hide();

    /**
     * @description 提示框渲染完时触发
     * @name magic.Tooltip#onload
     * @event 
     * @grammar magic.Tooltip#onload()
     * @example
     * var instance = new magic.Tooltip();
     * instance.on("load", function(){
     *     //do something...
     * });
     * @example
     * var instance = new magic.Tooltip();
     * instance.onload = function(){
     *     //do something...
     * };
     */  
    instance.fire("load");

    return instance;
};
module.exports  = magic['setup']['tooltip'];
