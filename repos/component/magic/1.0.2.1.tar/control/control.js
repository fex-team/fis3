var baidu = require('common:static/common/lib/tangram/compatible/compatible.js');
var magic = require('common:static/common/lib/magic/magic.js');
/*
 * Tangram
 * Copyright 2011 Baidu Inc. All rights reserved.
 *
 * namespace: magic.control
 * author: meizz
 * version: 0.1
 * date: 2011/11/28
 */

///import magic;

/**
 * 按 VCD 模式，将 Control 与 View 分离，所有模块的 control 皆放在此空间下
 * @namespace magic.control
 * @name magic.control
 */
magic.control = magic.control || {};

module.exports  = magic['control'];
