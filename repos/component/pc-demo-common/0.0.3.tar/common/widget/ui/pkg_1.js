console.log('pkg_1');
require('pkg/pkg_1.js');