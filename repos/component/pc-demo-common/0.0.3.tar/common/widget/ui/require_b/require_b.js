console.log('require_b');
require('../require_a/require_a.js');