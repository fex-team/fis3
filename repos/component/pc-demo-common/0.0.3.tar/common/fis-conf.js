fis.config.merge({
    namespace: 'common',
    pack : {
        '/static/common/pkg.js' : ['**.js']//[/ui\/pkg_\d+\.js/i]
    }
});