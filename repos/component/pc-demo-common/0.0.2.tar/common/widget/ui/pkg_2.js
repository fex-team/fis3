console.log('pkg_2');
require('pkg/pkg_2.js');