console.log('require_c');
require('../require_b/require_b.js');
require('../require_a/require_a.js');