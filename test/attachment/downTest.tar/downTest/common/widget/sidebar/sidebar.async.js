exports.run = function(){
    $('html').toggleClass('expanded');
};