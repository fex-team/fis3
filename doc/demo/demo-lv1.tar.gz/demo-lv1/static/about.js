function app() {
  console.log('about');
}

app();