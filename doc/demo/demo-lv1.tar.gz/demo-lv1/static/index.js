function app() {
  console.log('index');
}

app();